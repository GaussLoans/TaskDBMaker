package com.scb.gauss.loans.service;

import java.util.List;

import com.scb.gauss.loans.bean.Task;

public interface TaskServiceInt {


	List<Task> showData();

	int addData(Task task);

}
