package com.scb.gauss.loans.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.gauss.loans.bean.Task;
import com.scb.gauss.loans.service.TaskServiceImpl;

@RestController
@RequestMapping
public class TaskController {

	@Autowired
	private TaskServiceImpl taskService;


	/* Adding a resource */
	@PostMapping("/addData")
	private int addData(@RequestBody Task task) {
		return taskService.addData(task);
	}



	/* Getting a list of resources */
	@GetMapping("/showData")
	private Collection<Task> showData() {
		return taskService.showData();
	}


}