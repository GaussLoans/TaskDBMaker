package com.scb.gauss.loans.dao;

	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.jdbc.core.JdbcTemplate;
	import org.springframework.jdbc.core.RowMapper;
	import org.springframework.stereotype.Repository;

import com.scb.gauss.loans.bean.Task;

	@Repository
	public class TaskDaoImpl implements TaskDaoInterface{

		@Autowired
		private JdbcTemplate jdbcTemplate;

	

		


		@Override
		public  List<Task> showData() {
			String query = "SELECT * FROM task";
			return jdbcTemplate.query(query, new TaskMapper());

		}

		class TaskMapper implements RowMapper<Task> {

			@Override
			public Task mapRow(ResultSet rs, int rowNum) throws SQLException {
				Task task = new Task();
				task.setTransaction_ref_no(rs.getInt("transaction_ref_no"));
				task.setCurr_step_name(rs.getString("curr_step_name"));
				task.setLast_step_name(rs.getString("Last_step_name"));
				task.setProcessDate(rs.getString("Process_date"));
				task.setStatus(rs.getString("status"));
				

				return task;
			}

		}
		
		@Override
		public int addData(Task task) {
			// TODO Auto-generated method stub
			String query = "INSERT INTO task(transaction_ref_no, curr_step_name, last_step_name, process_date, status) VALUES (?, ?, ?, ?, \r\n" + 
					"            ?);\r\n" + 
					"";
			return jdbcTemplate.update(query, new Object[]{
					task.getTransaction_ref_no(), task.getCurr_step_name(),task.getLast_step_name(),task.getProcessDate(),task.getStatus()
			});
		}
		
		
		}
		

