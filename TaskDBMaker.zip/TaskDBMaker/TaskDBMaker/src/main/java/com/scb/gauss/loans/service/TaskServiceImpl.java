package com.scb.gauss.loans.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.gauss.loans.bean.Task;
import com.scb.gauss.loans.dao.TaskDaoImpl;



@Service
public class TaskServiceImpl implements TaskService {
	

		@Autowired
		private TaskDaoImpl taskDao;
		
		@Override
		public int addData(Task task) {
			return taskDao.addData(task);
		}


	
		

		@Override
		public List<Task> showData1() {
			return taskDao.showData1();
		}

		@Override
		public List<Task> showData2() {
			return taskDao.showData2();
		}
		
		@Override
		public int gentransaction(int id,Task task) {
			return taskDao.gentransaction(id,task);
		}





	
		
		


	}
