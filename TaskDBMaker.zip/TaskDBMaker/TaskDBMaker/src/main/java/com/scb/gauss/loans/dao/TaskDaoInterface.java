package com.scb.gauss.loans.dao;

import java.util.List;

import com.scb.gauss.loans.bean.Task;

public interface TaskDaoInterface {

	List<Task> showData1();
	List<Task> showData2();
	int gentransaction(int id,Task task); 
	int addData(Task task);

}
