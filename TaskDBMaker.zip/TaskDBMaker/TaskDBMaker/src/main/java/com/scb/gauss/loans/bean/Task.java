package com.scb.gauss.loans.bean;

import java.util.Date;



public class Task {
	private int transaction_ref_no;
	private String curr_step_name;
	private String last_step_name;
	private Date processDate;
	private String status ;
	
	public Task() {}

	public Task(int transaction_ref_no, String curr_step_name, String last_step_name, Date processDate,
			String status) {
		super();
		this.transaction_ref_no = transaction_ref_no;
		this.curr_step_name = curr_step_name;
		this.last_step_name = last_step_name;
		this.processDate = processDate;
		this.status = status;
	}

	public int getTransaction_ref_no() {
		return transaction_ref_no;
	}

	public void setTransaction_ref_no(int transaction_ref_no) {
		this.transaction_ref_no = transaction_ref_no;
	}

	public String getCurr_step_name() {
		return curr_step_name;
	}

	public void setCurr_step_name(String curr_step_name) {
		this.curr_step_name = curr_step_name;
	}

	public String getLast_step_name() {
		return last_step_name;
	}

	public void setLast_step_name(String last_step_name) {
		this.last_step_name = last_step_name;
	}

	public Date getProcessDate() {
		return processDate;
	}

	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Task [transaction_ref_no=" + transaction_ref_no + ", curr_step_name=" + curr_step_name
				+ ", last_step_name=" + last_step_name + ", processDate=" + processDate + ", status=" + status + "]";
	}
	
	
	
}
	
	
	
