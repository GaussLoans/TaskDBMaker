package com.scb.gauss.loans.dao;

	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.*;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.jdbc.core.JdbcTemplate;
	import org.springframework.jdbc.core.RowMapper;
	import org.springframework.stereotype.Repository;

import com.scb.gauss.loans.bean.Task;

	@Repository
	public class TaskDaoImpl implements TaskDaoInterface{

		@Autowired
		private JdbcTemplate jdbcTemplate;

	



		@Override
		public  List<Task> showData1() {
			String query = "SELECT * FROM task where curr_step_name='opsmaker' and status='pending'";
			return jdbcTemplate.query(query, new TaskMapper());

		}

		class TaskMapper implements RowMapper<Task> {

			@Override
			public Task mapRow(ResultSet rs, int rowNum) throws SQLException {
				Task task = new Task();
				task.setTransaction_ref_no(rs.getInt("transaction_ref_no"));
				task.setCurr_step_name(rs.getString("curr_step_name"));
				task.setLast_step_name(rs.getString("last_step_name"));
				task.setProcessDate(rs.getDate("process_date"));
				task.setStatus(rs.getString("status"));
				

				return task;
			}

		}
		
		

		@Override
		public  List<Task> showData2() {
			String query = "SELECT * FROM task where curr_step_name='opschecker' and status='pending'";
			return jdbcTemplate.query(query, new TaskMapper1());

		}

		class TaskMapper1 implements RowMapper<Task> {

			@Override
			public Task mapRow(ResultSet rs, int rowNum) throws SQLException {
				Task task = new Task();
				task.setTransaction_ref_no(rs.getInt("transaction_ref_no"));
				task.setCurr_step_name(rs.getString("curr_step_name"));
				task.setLast_step_name(rs.getString("last_step_name"));
				task.setProcessDate(rs.getDate("process_date"));
				task.setStatus(rs.getString("status"));
				

				return task;
			}

		}
		
		@Override
		public int addData(Task task) {
			// TODO Auto-generated method stub
			String query = "INSERT INTO \"task\" (curr_step_name, last_step_name, status,process_date) VALUES (?, ?, ?,?)";
					
			return jdbcTemplate.update(query, new Object[]{
					 task.getCurr_step_name(),task.getLast_step_name(),task.getStatus(),java.time.LocalDate.now()
			});
		}
		
		public int gentransaction(int id,Task task) {
			
			String query = "UPDATE \"task\" set curr_step_name=?,last_step_name=?,status=?,process_date=? WHERE transaction_ref_no=?";
			int row= jdbcTemplate.update(query,task.getCurr_step_name(),task.getLast_step_name(),task.getStatus(),java.time.LocalDate.now(),id);
			return row;
			
		}
		
		
		}
		

