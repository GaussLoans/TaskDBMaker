package com.scb.gauss.loans.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.scb.gauss.loans.bean.Task;
import com.scb.gauss.loans.service.TaskServiceImpl;

@RestController
@RequestMapping("/task")
public class TaskController {

	@Autowired
	private TaskServiceImpl taskService;


	/* Adding a resource */
	@PostMapping("/addData")
	private int addData(@RequestBody Task task) {
		return taskService.addData(task);
	}



	/* Getting a list of resources */
	@GetMapping("/showData1")
	private Collection<Task> showData1() {
		return taskService.showData1();
	}
	
	@GetMapping("/showData2")
	private Collection<Task> showData2(){
		return taskService.showData2();
	}
	
	@PutMapping("/update/{id}")
	private int generatetransaction(@PathVariable int id,@RequestBody Task task) {
		System.out.println("trans no:" +id);
		return taskService.gentransaction(id,task);
	}


}