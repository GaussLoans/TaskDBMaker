import React from 'react'



class FormCreation extends React.Component {
    render() {
        return (<div>
            <div className="row" >

                <div className="col-sm-8 col-sm-offset-2">
                    {/* <h1 style={{ alignContent: 'center', textAlign: 'center', color: 'white', marginTop: '10px', marginLeft: '400px' }}>Form Submitted Successfully</h1> */}
                    <div className="panel panel-default">

                        <div className="panel-body">
                            <form className="form-horizontal" >
                                <div className="but-al">
                                    <div className="form-group">
                                    <h1 style={{ alignContent: 'center', textAlign: 'center', color: 'black', marginTop: '10px', marginLeft: '100px' }}>Loan Approved</h1>
                                        

                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div >
        );
    }

}


export default FormCreation