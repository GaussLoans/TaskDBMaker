import React, { Component } from "react";
import { Button, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import "./Login.css";
import ud from '../containers/bg3.jpg'






export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userid: "",
      password: ""
    };
  }

  validateForm() {
    return this.state.userid.length > 0 && this.state.password.length > 3;
  }

  handleChange = event => {
    this.setState({
      [event.target.id]: event.target.value
    });
  }

  handleSubmit = event => {
    event.preventDefault();
  }

  render() {
    return (
   
      <div style={{ backgroundImage: "url(" + ud + ")", backgroundRepeat: 'no-repeat', height:1000, backgroundSize:'cover', marginTop: -17, backgroundPosition: 'center' }}>
       <br></br>
       <br></br>
       <br></br>

       <h1 style={{paddingLeft:'450px', paddingTop:'100px', fontSize:'12', color:'white', fontStyle:"bold", fontFamily:"Titillium Web"}}>Standard Chartered Login</h1>
       

            <form onSubmit={this.handleSubmit} style={{paddingLeft:'400px', paddingRight:'400px', paddingTop:'100px'}}>
              <FormGroup controlId="userid" bsSize="large" >
                <ControlLabel style={{color:'white'}}>UserID</ControlLabel>
                <FormControl
                  autoFocus
                  type="number"
                  
                  value={this.state.userid}
                  onChange={this.handleChange}
                />
              </FormGroup>
              <FormGroup controlId="password" bsSize="large">
                <ControlLabel style={{color:'white'}}>Password</ControlLabel>
                <FormControl
                  value={this.state.password}
                  onChange={this.handleChange}
                  type="password"
                />
              </FormGroup>
              <Button className="btn btn-success"
                block
                bsSize="large"
                disabled={!this.validateForm()}
                type="submit"
                
              >
                Login
          </Button>
            </form>
          </div>

          );
        }
      }

