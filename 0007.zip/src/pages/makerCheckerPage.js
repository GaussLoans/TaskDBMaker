import React, { Component } from "react";
import ReactTable from "react-table";
import "react-table/react-table.css";
import Avatar from '@material-ui/core/Avatar';
import Chip from '@material-ui/core/Chip';
import LockIcon from '@material-ui/icons/Lock';
import UnLockIcon from '@material-ui/icons/LockOpen';
import EditIcon from '@material-ui/icons/BorderColor'
import { Tooltip } from "@material-ui/core";
import MakerCheckerComponent from '../components/makerCheckerComponent'
import { throwStatement } from "@babel/types";

class MakerCheckerPage extends Component {
  // Empty State for Future Use
  state = {
    makerCheckerDialog : {
        open : false,
        data : {
            headerTitle: 'Maker Process'
        }
    },
    tableData: [
      {
        transaction_ref_no: 1,
        curr_step_name: "Operations Maker",
        last_step_name: "Loan Form",
        processDate: "09-12 9:58AM",
        status: "Complete"
      },
      {
        transaction_ref_no: 2,
        curr_step_name: "Operations Maker",
        last_step_name: "Loan Form",
        processDate: "09-12 9:58AM",
        status: "Editing"
      },
      {
        transaction_ref_no: 3,
        curr_step_name: "Operations Maker",
        last_step_name: "Loan Form",
        processDate: "09-12 9:58AM",
        status: "Pending"
      }
    ]
  };

  makerCheckerDialogCloseHandler = ()=>{
    this.setState({
      makerCheckerDialog: {
        ...this.state.makerCheckerDialog,
        open : false
      }
    });
  }

  openMakerCheckerDialogHandler = (data)=>{
    this.setState({
      makerCheckerDialog: {
        ...this.state.makerCheckerDialog,
        open : true
      }
    })
  }
  columnDefination = [
    {
      Header: "",
      accessor: "df",
      width: 80,
      filterable : false,
      Cell: row => (
        <div style={{ textAlign: "center" }}>
          {row.original.status === "Pending" ? (
            <UnLockIcon style={{ width: "25px", height: "25px" }} />
          ) : (
            <LockIcon style={{ width: "25px", height: "25px" }} />
          )}
        </div>
      )
    },
    {
      Header: "Transaction Ref No",
      accessor: "transaction_ref_no"
    },
    {
      Header: "Curr Step Name",
      accessor: "curr_step_name"
    },
    {
      Header: "Last Step Name",
      accessor: "last_step_name"
    },
    {
      Header: "Process Date",
      accessor: "processDate"
    },
    {
      Header: "Status",
      accessor: "status",
      Cell: row => (
        <div>
          <Chip
            avatar={<Avatar>{row.original.status[0]}</Avatar>}
            label={row.original.status}
            clickable
            color="primary"
            deleteIcon={<EditIcon />}
          />
        </div>
      )
    },
    {
      Header: "Actions",
      accessor: "firstName",
      filterable: false,
      Cell: row => (
        <div>
          <Tooltip title="Edit">
            <EditIcon style={{ width: "25px", height: "25px" }} onClick={()=>this.openMakerCheckerDialogHandler(row.original)} />
          </Tooltip>
        </div>
      )
    }
  ];

  editHandler=(row)=>{
    console.log(row);
  }

  render() {
    return (
      <div>
        <ReactTable
          filterable
          data={this.state.tableData}
          columns={this.columnDefination}
          defaultPageSize={10}
          className="-striped -highlight"
        />
      <MakerCheckerComponent content={this.state.makerCheckerDialog.data} open={this.state.makerCheckerDialog.open} closeHandler={this.makerCheckerDialogCloseHandler}/>
      </div>
    );
  }
}

export default MakerCheckerPage;