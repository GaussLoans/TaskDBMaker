import React, { Component } from "react";

class LoginContainer extends Component {
  // Empty State for Future Use
  state = {};
  render() {
    return <div>LoginContainer</div>;
  }
}

export default LoginContainer;
