import React, { Component } from "react";
import MakerCheckerPage from "../pages/makerCheckerPage";

class DashboardContainer extends Component {
  // Empty State for Future Use
  state = {};
  render() {
    return (
      <React.Fragment>
        <MakerCheckerPage/>
      </React.Fragment>
    );
  }
}

export default DashboardContainer;