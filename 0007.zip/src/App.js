import React, { Component } from "react";
import { HashRouter, Route,Switch } from "react-router-dom";
import DashboardContainer from "./container/dashboard";
import LoginContainer from "./container/login";

class App extends Component {
  // Empty State for Future Use
  state = {};
  render() {
    return (
      <HashRouter>
        <Switch>   
              <Route path="/" exact component={DashboardContainer} />
              <Route path="/login" exact component={LoginContainer} />
        </Switch>
      </HashRouter>
    )
  }
}

export default App;
