import React from "react";
import { MDBContainer, MDBRow, MDBCol, MDBBtn } from 'mdbreact';

const FormPage = () => {
  return (
      <div>
    <div style={{ backgroundImage:"url('https://cdn.pixabay.com/photo/2017/03/02/08/58/background-texture-2110724__340.jpg')",backgroundSize:'cover', marginTop:"100px", marginLeft:"100px", marginRight:"100px"}}>
    <MDBContainer>
        
      <MDBRow>
        <MDBCol md="6">
          <form style={{marginLeft:'70%',marginTop:'20%'}}>
            <p className="h4 text-center mb-4">Login</p>
            <label htmlFor="defaultFormLoginEmailEx" className="grey-text">
              Username
            </label>
            <input
              type="text"
              id="defaultFormLoginEmailEx"
              className="form-control"
            />
            <br />
            <label htmlFor="defaultFormLoginPasswordEx" className="grey-text">
              Password
            </label>
            <input
              type="password"
              id="defaultFormLoginPasswordEx"
              className="form-control"
            />
            <br/>
            <div className="text-center mt-4">
              <MDBBtn color="success" type="submit">Login</MDBBtn>
            </div>
          </form>
        </MDBCol>
      </MDBRow>
    
    </MDBContainer>
    </div>
    </div>
  );
};

export default FormPage;