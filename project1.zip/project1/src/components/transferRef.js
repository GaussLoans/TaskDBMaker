class tableData{
    constructor()
    {
        this.ref ={
            current:"opsmaker",
            last:"opschecker",
            status:"pending"
        };
    }
    getref()
    {
        return this.ref;
    
    }
    setref(ref){
        this.ref=ref;
    }
}
let data =  new tableData();
export default data;