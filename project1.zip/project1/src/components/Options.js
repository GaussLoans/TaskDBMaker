import React from 'react'
import ud from '../components/bg3.jpg'
import { Link } from 'react-router-dom';
class Options extends React.Component {
    render() {
        return (
            <div style={{ backgroundImage: "url(" + ud + ")", backgroundRepeat: 'no-repeat', height: 550, backgroundSize: 'cover', backgroundPosition: 'center' }}>
                <div className="row" >
                <div className="bt1">
                    <Link to="/frontdesk">
                    <button type="button" class="btn btn-success btn-lg" style={{marginTop:"140%" , marginLeft:"40%",fontSize:'200%'}}>Front Desk</button>
                    </Link>
                    </div>
                    <div classname="bt2">
                    <Link to="/opsmaker">
                    <button type="button" class="btn btn-success btn-lg" style={{marginTop:"90%" , marginLeft:"200%",fontSize:'200%'}}>Operations Maker</button>
                    </Link>
                    </div>
                    <div className="bt3">
                    <Link to="/opschecker">
                    <button type="button" class="btn btn-success btn-lg" style={{marginTop:"83%" , marginLeft:"280%",fontSize:'200%'}}>Operations Checker</button>
                    </Link>
                    </div>
                </div>
                </div>

        );
    }
}
export default Options;