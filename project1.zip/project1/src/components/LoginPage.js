import React from 'react'
import { Link } from 'react-router-dom'
//import FinalForm from './subscribeForm';
import transferRef from './transferRef';
import axios from 'axios';

class LoginPage extends React.Component {
    state = {
        customer: {
            country: '',
            customer_name: '',
            address: '',
            company: '',
            salary: '',
            loan_amount: '',
            loan_type: '',
            aadhar: '',
            pancard: '',
            email: ''
        },
        done: false,
        doneu: false
    };
    handleChange = (evt) => {
        // const value = evt.target.value;
        // const name = evt.target.name;
        let customer = { ...this.state.customer, [evt.target.name]: evt.target.value }
        this.setState(
            {
                customer: customer
            }
           
        );
        console.log("Change");
    }
    handleBack=()=>{
        axios.put(`http://localhost:9091/task/update/`+encodeURIComponent(this.state.customer.transaction_ref_no),
        {
           curr_step_name:'opschecker' ,
           last_step_name:'opsmaker',
           status:'pending'
        }).then(res => {
            this.setState({
                doneu: true
            })
            console.log(this.state.doneu);
        })
        
    }

    handleSubmit = (evt) => {
        evt.preventDefault();
        console.log(this.state.customer);
        const customer = this.state.customer;
        console.log(this.state.customer);
        console.log("Submit");
        axios.post('http://localhost:9091/customerinformation/add', customer).then(res => {
            this.setState({
                done: true
            })
            console.log(this.state.done);
        })
            .catch(err => {
                this.setState({
                    err: true
                })
            });
            
       this.handleBack();
            
    }



    getCustForm = () => {
        return (<div>
            <div className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <div className="navbar-header" />
                    <ul className="nav navbar-nav container">
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAMAAACahl6sAAABXFBMVEX///8goUQAdKB5r8mdzJj8//////35///2/////v/0//8fokTw///t//8AdaB5r8sAc6Kdy5r7//vl///j///0//n6//l7rsYkn0XP7vTJ+f/f///u//Y+iqgJcZigyJwicIwPbI5AgZjK8/+Px9sQZYTE7vAZZ4N/q8APbZHk/+8mnUgql0is1+QPYoMUcJFkmqtWm7S40t6Jrb1CgZYqeJWXy9SkxZ8nb4iZz5hCmFvV9+DM4ukokkaNvcZpqLqqv8nY7fSUtcOEpbLP6/A0i61XrNDS6NGtx6vA2r7R5c7j8uBwuNVKoMLB2uS3z7R+vdOg1+uy0q5go7+avqGz4sFHjFaAwpNZr2tUo2t+0o7M/tqW1JnF7NKuwayOzqBrvXlqq39is3if2LBXoW6d17CEyplGnl5spbIRWXNKdICJzOWQ3vey4fV0sb617vYtXm24+v+a6P9Uqb2UvBLwAAAZFElEQVR4nO1diVvbVrY30KsrC4nFsjFCtvA1yLIAL4DluCx2TJKmbSglYTJpps3LS5NMkukA03n///e9c+6VZHnLMlMsp19O+8WbZPTTOb+z3cWJxCREkibyZ25a/hwoEggkGfcl/FHypwGC8qcxsD+B/KkMC+AkP3vj4gAIJX8GIIRqt1X6udlYcOeT/oVLhKp7++X9I0rgRfJzg8OvF5WRoEp3v5xdzJb3ZCI++uzASL5VAYy5xbls+YgQDvAzyb2k6FOinu1nswBjbg500qXS5wmEymBVi4gCcCwuZk8UEt91fbIgELznEiEqWJUAwXUyV96jcV/dpwjedSkpEeVoX+AQUECy+2ryc8u6CO2eoK+a6xNgSdwX9gkCrglDR3kABFfJ3udEEoACoSMLzmoISvbks9FIEiM5WtWwOtAD78txX+D7pC9Qg686K2dH4gAgd+jnktYTkZAsjgHCNTLdAdHP1jUROkYDyQqOTDeQBMJQjzjJx0p2b/qBSBKROcl5XjVaI3OQN8Z9ne8V5C+QHEKHz45xSilr017DExpNSMZa1gn3vlNsWkS+61vVGJsSOMoaj4fTiENck6xv1iO+aqxh7dGppQgvAhW94QxqYhhMFnJfErEqaZqawpiUp+QNz73HgSz2X3gfLsDRJeKcCEkkSUpNBWXA6SqGbVnfLIbVky+LvloCkyufCIJE1SBJufvfPkjFDYSbVUJZ86xZBDJE9MXeI/ZQVNpPc9DlyoNH6+u3vl+JGYlokphFawGBoEqyY5Bk/a4WXLx/zfBEWnnw3a315eXlW/dTUuyejKgdd3aWAxlHd8hZ0KySvsOS/H9Tme85jK++AiQrsQORK9WFWURyutjPkd5TgNEFdfRRWkql7j9aBxBclm89SMWGwLcsLW/NLnGVDOgj5Hp2f08BHCQ8Bx9Wct/dQm34UJa/zcQcYOiaPQtAlmYX7p0OOF/frNCq+kCgOlbQqjgCH8j6/ThVgpkJMmSJ29a90+HsBGAcycG9liTR7gKS/7geKsNH8iheH0x1hzOEI7FCJH7oyJaFz+0JYgGrWu8DwWX9QaxA5Lu1WV8j8DCgFJ/kQggfZkhGrKpPlte/j1MlRGnWuEaAI0IpP5zyeMKB7J/RgRyRpLhVcZ87qJEfY4yKUkI5t0KNLOCjBVo55QUiZFZyUgqSK3F8Kvcjho5hfSwDkEycGlFPhfMNiQKv3HvfoIVlbytERDketTE5FBFwCIbQyKN4gVwIICES4cAsgJLdk4nvdhO+r/oWfdUYIMsxa2TXmo3IkiDLwhKSJavTXvUBvmq0VU0HR4g61wfEF8QCZDk3lWBMWlq5L3zVKJ5Pg9dSz7lpLY1CY7neQ5OPUJFE5ttbI33VV4GpQbYVo0IkdL8hM0aI610JrYDX5YY1CCV8vfwoTsuSEnKp9h4cqBXnytBkiiXUdyM4Er5eh0Q+TqF6YWEskIUF+N+yao0NDRIVspK779cfw65r+VYuxqQRNELkXWu8QnyvbLF8W1doaiWVgRqkp5YenJjrEYzY1GT+zQ+vO4ohCCyus2mqFDIUDCbrgya2vP5dvIYFWSDRMJJEAQQyoCe3sLumQYjsIwtn/zLgiDMYciSgEsOxRgIZtLAFt7pbSSuolq3vHwVlFTys3/ouk5qCNqpSqY3j+kIEyAInSwssTCbSiiCL8Fe37q8g22IHQrSwSPywQJB8ayi+hSFXQB252PtzonaVqNZh/K6PNbClPijVixInSwrIcuvHByvx4xCSTMjaOQup8H7xI4v3UOdayT3IpMKGXfxCiFrxXMh5h+//GDSWXWwb4I4hOwYAfNbmNADBktcs1iw/xn8UXRYsJ2voCpm64RKqXnvM+rBt+SrhUGqNS0WeLiQElaK1i24kpLwPFFfa0oIFkUXlJctUjJAkeEEuEaroly1XaAVjyMeox6rt8jw//ma8EH5PCWql0rHfG1UWQl35ON3ClUanBghIKpNbSaUIVdfq7yPLABAo8RfYrjE1Mx0JyeT+gsFtJUWpYj4sMCuo5RdGYAr89JJ45nollUzHuGgq8/ivT5bX1x/dh3yDUFlt7jJ3RKGy1EecJf/zBatQUmLNtURvHZKUrScHP/2CdQVkgLkV5L22VueBZTTllwYgWgVT5glPjO4LG4iHT493/va1XyPd+u4BcIXImnFecK0BUxLk6IfB82IvzWcNxYcC/s88O9heDYBg4wrIkkmRFFXS50VmzS6FF74UXvggkFn3SiXxAeGZUubwYHtmJtQI18r6t99nwMKIrJeKPd6PgSKKYXtDjpfwqa2n26shkKCEFXVGKkVlpdRhLremcS55gcdPq67FiAJw5F7szMzMrG4HptVrKABZVrDPoupXnhu9+8PhEvOAmkHijIqpn49BH4Dkp18GkQCUb++vpAgklGalaI9qEgcegDeLm0p8MBIkxw0LgAjbWu5DAlhEZAEfVuGRZbwsWA2cNh+XTlLPhEJmZrZRJV/3QIh/QCv/s4KzmQjVzItC7X1QnDRJSjEhkTLPd2bmQR8+khHWdd/vLWDANzY91MowR/g79gaJyWvB7cv8tD0TCFhXP0+460KSBAJkOfes6NUvRMbt2HV8qWMq51vW/Pz8zPzq9k8CynIQTTAwRo+HwJI9/cGN6GSp94RVYtOIT5F5H8g8KEVA4UBufb+SGrzHRD2ZOz39wXJHFF5uJS6NSInM4xCIb14cyi9cIQ9GDN1QvYyTIk6/qVlDvI8PCElkXnPTClAIKNs7//vLL1/jEFQyks7iA6Hdfb6Qb3Hu9Jt7g0jAtGILiJnXO6szg8Kh/O3rRxmOIVgdCsEE11xlgxmOi6en9yyRCi+JfNg24wRyHAWCRBFYtnd++uVZJhhmRzRQo/gT58PlYwhloZeDtbQYvdbjPiAz8yFZZrZ33jzf8p1WuD4U1yIu9ualAVfCaL9gZWNMUXqBPaqVEMrBy8NcSpQZ9OwOTpznU84D88L/TwPSL7ilGFdfkVwUCMcQAplHA3vz4jCHozgJiisAsovhRGCOhSPxo4rl6TFmvyTz6/bM+2R15/jXxzkospJUPjopB0qJzOo6/UHMZWFtJc5CN/NyJ/S+MzN9T8VzcGHHBy+3MpRArqWdoFr6F8ksfiOK9qIaY29LklK8zu1dfxRTjyzHb54cIhTI5s9wIVnftMdT3mypGjEu6yO4GOnJzmq/IoaBoIUdPHmGfSJC1bO+JYqLAghrxtpsRG8kVPJBAQt79QzdsR9Psv5kZwRizbKrOA1LSOYlOK5RGhlQCkJ5+ppDgUxlr1zmC2AX0bQsu6mSuDcbSaYyaFyQ/Q7nKr7Jzfeg7Bw8x8hCKITHfbF6dPHCLVRUOgXd+NTWi53V1ciFz4x5Ps+hvHn1M0IhsirWli0W6yaf/DgFSHIvjhFJmGmNANILlUiWxz5Zjm6Xy+W2JvNOX/xAAMnz4+1RljUz0h+DWv76ciuHWBR9T0N1TMvIG8k8PgCijMEyLCJ3yXDik6laYJnKbL0IlTI/zolFkPi5SypclTgVpgVCVnKHr6L21Yv1Y1Dx3AXIMi1W5YuUIKnc41+Pg4JxPgJkRCoW8v7py1yGTw6eFjhSIkkAys+v3uz00X5+NJDwObiwQ+zgTZdeAErm8PkBQBnSy3i2bL95nRnqGsUmkliRiHOX5K3XTzlZ+qP6kMwH/24fP9maHiR8c4GzLi4Ko5ncs4D379PIfGheO0+34l1gFRHI57EAPDmTsewAKE8OdvyO10eYFyKZEpbQLu6hxReA4jQsJMuTNz0L+yCSF1MwHxCEKv72OritWfm2imqhma2XB8ch798PaPX4dYbEuw0aJhn0CHc7Ei0rXO1dvt3lUGQeWfy6a/695N8+OIyRJskk33lDPyn7W5r51SsuojQUwsly+OJNmOT3gAz55dWd55n4gPBhKGVvP7IAP1yIWD7Bda0YJA+5hY21Lz/53z7Yio8lUoLvvDHnt0X6FrSDVvb3uggFyIKRZRw9fOWs7ryOb1o5odrwpk2hkWWz2f0TTaE0kUpt/fz0GAP+iER/3h+N2HmViwtHghzxbQsX+zaqiO4blOVLdSmRUqnMs78f74yrvnh79c1WfEDOylFdDK/MFxZ2hK03IMvWkzd+GtZPFT8VPj6MD8hReWCXh8jK/Gzgwu74e6GkMrmtx68ikSWqEJCdw/jI3t3P9vmquYEtBrJi3XGw4SG648eYu6zOjwQSW+YoySdiz6M+tYQGtoh7Pez1TbaWJHDHaGEjeBIjEMiw/O0k+3GEVlW+rfUvn8ZSMKhZ+t0vuK34OJJIqCd9MT1UCPI+mz0ZWgbOBTLK3PM3O315PritGL1WIkmPxm5EBepQR2y6LPZ3Axf28kCkLoFG4nS/uMLq9ggki73NBQarjKAVBwa29frgWPQnRY7yKheb10ryKRmIJDsAhO+v469l75NwMbWUIJmt5we+geHkj/X4UhSxL8pJ/xDU4sBeD6PbodyVAe3/zuPKKlbucebxKFTtsy4MHftnvVUh773LqZXMs19Farz9NO4dXhJQreNQh1ALT3rVsTiSwY7fkr9xDYZI3jY+fpwZcfxkBTdnxJFnjH+QJPaFjg9fGNgXKAXLkY87/iYFiw7taO/27b0zDWvcTzoZg/3zg4Ofp6UhRHz55LEOCfenOvxLToqbIih8u0lh936Y+CQwEkmRWNtao/o309Cd+iPlP7jB03kLPpUoN3QZ/5n8N43C6ULSk0/CJH36KRMR3wV87D2O110FHlfIcLr+MVcn9T+LnjEp7Ug8/smKH8VFZ0EKp5TirxGMRUJGpGFSIjrxgUxuRbWUoFp6Y7O8WUrjbBiJUFxtGwEyoJLeczhPGzXBLHI4UQ19QrM0JYnqbz2G4l3hXnmq0ZU/bu6x0nYafGaWGHP0v44/+NQitOIU1Ru57mGh2oXN8vW3ux6z6xqhe+8cPQIk3Kit76QkroZR26wHJNx8sk8jtMLyk5nJLBGlzex2WtO0dIdVL2W5YrdM/08TXDkhDW7oK17BIWq7EEzCJLh8J+FXJsSfKUtQIwBkInSXiLbrFjUKf52aHqsrSsUumDKnCZUVFYdF+PodHLNSZLFYnX+kyD4Q/xWnAhKMyDLuEYpvUqXi5ie0kI9oeXdXI8hutd76BwBhtd82b6tQlBjter3TNACLvNc00pVO/byEuxXDR6VsvXy91mYAhMj6Rrbe2Sxp4KG02001Xamf4CGderlkXk8KCNeIc83vPFV1TYZ7aLm2o8lqvcAcm7FCRSFqw/4t79jwqg5IqN5g+JF3ikBoyWNwAmMNqCY33tlrxZrdUdJwCIND/jkxjSSUiuO6F3DjZTQJgkA6b++oyrnNOs1K2wPDAyDuPbvebnZq9jUFHbJCp9ncdVyrqMpai3ntZvOCsYpMN6ruLvPym2qR1TrNNi7ymxDZ0dU/ZC6r2YXORlohgMuurYGC1KLd0VRFK7k1nWgN132oq6qeZ7tUvqyyS11RtU0GQOA+OBtwnLnL5mSyUbVY3dT0Nis0NTi+zayJaQSDVrPo2K5re20NNFItmLjhw0nbpJSqa1YtDUBYywSHIJ+zlix73DuA3867oJGz8r5KiaJfuBccSB4qfcE7LP6LEzOtJPorRTUr9Txzq+caAkkjPFnTDKOy6VkuB9KAC0vQTVaQ9QLblKVkkmhXNeSIqulGqTJXcy8UMC3WVCWie6zC148om7WJkV1WsXOF24eUPItVVHC/CATcTqPVchzma6Su4kEARDUK9iUff1OaSHY5vd+CAxkQTQGNAFMSJF3D9SMQPuRrNjEgR406RnL8ZaS1qnWuIRDwxmrHtnevmmdrtRAIZDMAROkWqpdUwv0p27Wiphge0KvdLPmmZRs0ACLhHtuTApIkhs1K4kcrqOZZWQ1NiyTkkmM/BLIrJQSiCo1wIOimzmXMrtQrMDitXmuZKrC9I0yLAwHT2sQNLJLq+aRMC/8oEBPnAhDFrLpNFYAYEAIrzDMVQtTrWs2kEEd6QJQG89IY6XVkPTiyTTid6rsciM2BQGxq4XdS05kc2eG+2h0DfKVWKrqOAWhqFU1Rrxm71lTt2rNqpqI1nB4Qec2pdUxNMy8gjgAQd9dUNfOcWReqLIAklFKVwSEq+OTJuV8KBKg5jXq94TCnohK1WGPOv3SjVSvU6y2n4Lr5Iw01gmNam3YLnGunVnN24XAEol0xt9hptJyaVXurCiCQiZ7Dl8A3FqzJAQE/2yzaXC5KYEzIXvudrlTgwa5erDVse0/9x7u6gkDa7xywGK3p4Ge7V3YDInvHrtpVp3lZdVraxrt3d9FdEW0TD7F3H1YnVo+g51XPmvvtisH3xyKKalRuK0TRztpoY1r7TKXdu13KB4KMrti0qtJuG2rX6AI7IJ7Cc0W92z5TlG5XLOaBCNnEQ3Qj/F27SSTzmLCrwTZfkIDLHBFP2xMUM3TiF/QUs3W+aRXk6KAhwosOBXcGhMMpT+OD71T427RX6d40EqycCOn1rDkYv+Eg2ghEHJQI34y0HfjvwIRlIm7Q2LvecJnyZBopw/U5pB/hRt5B/2HEiQJb/+8sSOHoVfTrJ9ivkwae9l0NVoX9zfpw2rivqGTk6CiESTXsCN+JFUXqldqjRxjCtz5yDn+0zP+vr/PDgjBkRdM0RZCU+D8q3bvs4dkOoTF9rJCRcz/+aIEoUs8X8/WmJmOqeHJHj/7REU3G4LKimw1EXgpj6zuhe2f/xqtECH9Fm0Gy7totiOpULzqlaPNwGAjR2ieq+Mg/JDjSP4B3j6K2STfeOXdvuN0I9aBTs+euS5enVdfZkGnasyNABjrTaIgSNWzH7Gt0f4gCkBI7xo0CgfrC9JhXgmRdUTc8VtBlBKKQSOcZI6FY58k9AjDKwHRK0ESESb4HDwYicRZ/U/JViZyDlPhmgeC863NWMLFZiFWV7ZRUAFaC0lXHPdXBPqBm13VdpSJzkSmUv5gXrmn4Fm5RpWsK7sVKVZVS8BnYndN0/imPkzJ+lXLzGqG649Z9HhKt3jgBjbDrhw3PK55DQZigZrbowQtgT0KuNy7TnWJD37Dde/lGFzehxQM7OpXw3LRR9+qQQl4VvWKjyVe5yvpbOL3Y/P2mgWAhWoXymwdv3MZQASDuadXxsJ+N1bjHmOcV3GpTJmqe/TvPWEvHjo/zrku1c8cueA4rmjJJe7Xf4ZyGZuzatlew7Y5GJdkoMvgq2/nGZcaNLt/l/WuTBLNGwRiA7JabXzOhTIIyUasz59o01/LY/lHz1j1WOK9oGzb73YTi9sq2K6Z57bCGjqfds73zDTPPCnD2b4y9VYneqPHTPcuCL7uZsOj/qjoUh62+cRi4tRZUuLIMBWyF6i17Q6FU+9320gBk1u2kFQoWb69BemwWategQrVUg9uN+K+w3Qr1MbgOrQmPoG5WQeqYnoUaucEFJUS9cnEfFt/DJMHFgGn9hn0ffZdtyspZBUhP9X/iZYFGGK6+oEYV3C82hvIm1sdQzZYVAAJ3hNBd1tH5m/dYSeu4+TT3Eh0O5CZFbbt2OrBeIjjCrhV4Q0Mg4If0y6uG51oCCB8MEUASdNeygNbwX81qqYD/XIVvcCwP3yuCgs71BgNHgrXLJW+t3KQoTVbdCIDIJ406jyOYqgCQh7JidJx37xzv/4RG3AtsAgVAipblVEWF/C+wHt6X02zLdcR79h39X+ytALKGceRGU0d613E7SuB+i2xO9SM7AtlU9CIrbAJ31xwOhJ3ibZV907pw87+vCTHAtNgGAJEL7m/+e2tprcFdO2rEB3KTJPFcuEYepOU15GbaE7kWAoHQ560p4JV9IG4AxDYAyMNqPo0jEaqe1pBaG1gVA0eQVfimqtRZHj0JUa7cG47sfNAV6AmVOfoWt2AoegSI1nbvmRDN1VPftM7xaohRZeDLwGsBm+BTvfiu7QORKO/qoaNy3t2VNxi75l4r75P9pjSCValWr9WKa2ndvC649qVCo0DUS2b9Gz7KAtnXVC3PBBCl6p6auqJ1WKFips0Oa6UpmhYYD9GLNW8tnV4rMog8etGFIzCOzN6s10L2Ub0O6a9XbNmu01YJ0f3sV3AEgrVXdJyLmuudAYU4kITStjGyy+YuRPZiwcGmHlALgUi0VOSnsJYhE/lui/HY/8NNmlagZqpVigWUBiaPVGu0eOmg1lt7VDEa8EGradYLrTN4p03EGVfwZhcSyKsWfFwsQVYGpxk8D1bMugef1k30GLJZLNQKhfrvrVb3xktEvidxqVQy+A8E4qgNDpZIEEIU3CSkaxiQ9Gp3dUi2tGBMHXNabGHBmUaXZ7qY/YrP+Ju64o9VKzq8wJ7ZBKZxYAsNhfj1A+nNABAfYqXB8/hwHgAWGSTpnxqcJ75N8ofacec9KZXg3y2+86ZbECQZtOAS/ZPGpPBp7/PeB5F/pMipvYlB4QHi7JtEEbYAJRIU2VJvv4boj0pzrJjzSf7LZOSSg/I83C8wPFH0GaWRU4z+UBwhkEgjoXdH+/5sACSMBMng/GQiOTj5Lxl57P+R7S/yRb7IF/kiX+SLfJEvMg3y/7EdK4AHwxDPAAAAAElFTkSuQmCC" height="5%" width="5%" />
                        <button className="btn btn-primary" style={{ marginRight: '80%', fontSize: '120%' }}>Home</button>
                        <button className="btn btn-success" style={{ fontSize: '120%' }} >Logout</button>
                    </ul>

                </div>
            </div>
            <div className="row">
                <div className="col-md-6">
                </div>
                <div className="col-md-6">
                    <h1 style={{ textAlign: 'center' }}>
                        OPERATIONS MAKER PAGE</h1>
                    <form className="form-horizontal" onSubmit={this.handleSubmit} >
                        <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }} >Name:</label>
                            <div className="col-sm-4">
                                <input type="text" className="form-control" id="customer_name" placeholder="Enter name" name="customer_name" value={this.state.customer.customer_name}
                                onChange={this.handleChange} required />
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }} >Company:</label>
                            <div className="col-sm-4">
                                <input type="text" className="form-control" id="company" placeholder="Company Name" name="company" value={this.state.customer.company}
                                onChange={this.handleChange}
                                    required />
                            </div>
                        </div>
                         <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }} >Country:</label>
                            <div className="col-sm-4">
                                <input type="text" className="form-control" id="country" placeholder="Country" name="country" value={this.state.customer.country}
                                onChange={this.handleChange} required />
                            </div>
                        </div>

                        <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }}>Email:</label>
                            <div className="col-sm-4">
                                <input type="email" className="form-control" id="email" placeholder="Email" name="email" value={this.state.customer.email}
                                onChange={this.handleChange}
                                    required />
                            </div>
                        </div>

                        <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }} >Address:</label>
                            <div className="col-sm-4">
                                <input type="text" className="form-control" id="address" placeholder="Address" name="address" value={this.state.customer.address}
                                onChange={this.handleChange}
                                    required />
                            </div>
                        </div>
                        <div className="form-group" >
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }}>Salary:</label>
                            <div className="col-sm-4">
                                <input type="number" className="form-control" id="salary" placeholder="Salary"  name="salary" value={this.state.customer.salary}
                                onChange={this.handleChange} required />
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }}>Loan Type:</label>
                            <div className="col-sm-4">
                                <input type="text" className="form-control" id="loan_type" placeholder="Loan Type" name="loan_type" value={this.state.customer.loan_type}
                                onChange={this.handleChange}
                                    required />
                            </div>
                        </div>

                        <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }}>Loan Amount:</label>
                            <div className="col-sm-4">
                                <input type="number" className="form-control" id="loan_amount" placeholder="Loan Amount" name="loan_amount" value={this.state.customer.loan_amount}
                                onChange={this.handleChange} required />
                            </div>
                        </div>

                        <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }} >Aadhaar Card:</label>
                            <div className="col-sm-4">
                                <input type="text" className="form-control" id="aadhar" placeholder="Enter aadhaar no" name="aadhar" value={this.state.customer.aadhar}
                                onChange={this.handleChange} required maxLength="12" />
                            </div>
                        </div>
                        <div className="form-group">
                            <label className="control-label col-sm-4" style={{ color: 'black', fontSize: '120%' }} >PAN Card:</label>
                            <div className="col-sm-4">
                                <input type="text" className="form-control" id="pancard" placeholder="Enter PAN no" name="pancard" value={this.state.customer.pancard}
                                onChange={this.handleChange}
                                    required />
                            </div>
                        </div> 
                        <select className="mdb-select md-form" searchable="Search here.." style={{ marginLeft: '40%', fontSize: '120%' }}>
                            <option value="" disabled selected>Documents</option>
                            <option value="1">Online Form</option>
                            <option value="2">Pancard</option>
                            <option value="3">Aadhar card</option>
                        </select>
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <div>
                            <button type="submit" className="btn btn-success" style={{ fontSize: '120%', marginLeft: '45%' }} >Submit</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>

        );
    }

    render() {
        console.log("happy friday");
        return (
            <div>
            {
                this.state.done ?
                    null : this.getCustForm()
            }
            </div>

            // console.log("happy friday")
        );


    }

}
export default LoginPage;