import React, { Component } from 'react';
//import FinalForm from './subscribeForm';
class Header extends React.Component {
    render() {
        return (
            <div>


                <header >
                    <div className="container-fluid">
                        <div className="row">
                            <div className="hh"
                                style={{
                                    "backgroundColor": "rgb(22, 168, 22)",
                                    "height": "10px",
                                    "float": "left",
                                    "width": "20%"
                                }}>
                            </div>
                            <div className="hhh"
                                style={{
                                    "backgroundColor": "green",
                                    "height": "10px",
                                    "float": "left",
                                    "width": "10%"
                                }}>
                            </div>
                            <div className="hhhh"
                                style={{
                                    "backgroundColor": "rgb(7, 7, 133)",
                                    "height": "10px",
                                    "float": "left",
                                    "width": "12%"
                                }}>
                            </div>
                            <div className="h"
                                style={{
                                    "backgroundColor": "steelblue",
                                    "height": "10px",
                                    "float": "left",
                                    "width": "7%"
                                }}>
                            </div>
                            <div className="he"
                                style={{
                                    "backgroundColor": "#0072AA",
                                    "height": "10px",
                                    "float": "left",
                                    "width": "50%"
                                }}>
                            </div>

                        </div>

                        <div className="hello">
                            <div >
                                <img src="s4.jpeg"
                                    style={{
                                        "width": "130px",
                                        "height": "75px",
                                        "float": "left"

                                    }} />
                            </div>
                            <div style={{}}>
                                <h2
                                    style={{
                                        "float": "left",
                                        "marginLeft": "5%",
                                        "color": "green",
                                        "marginTop": "2%",
                                        "fontSize": "20px",
                                        "textAlign": "center"


                                    }}>Welcome to Standard Chartered Online Banking</h2>
                            </div>



                        </div>


                    </div>
                </header >
            </div>
        )
    }
}
export default Header;
