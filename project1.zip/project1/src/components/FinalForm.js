import React from 'react'
import axios from 'axios'
//import bg3 from './bg3.jpg'
//import Header from './header'
import tableData from './transferRef';

class FinalForm extends React.Component {
    constructor(props)
    {
        super(props);
        this.state={
             ...tableData.ref
        }
    }    

    handleEvent = (e) => {
        e.preventDefault();
        var d=new Date();
        let date=d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();
        console.log(date);
        axios.post(`http://localhost:9090/task/addData`, {
          curr_step_name:this.state.current,
          last_step_name:this.state.last,
         // process_date:date,
          status:this.state.status
        })
            .then(res => {
                if (res.data > 0) {
                    alert("Customer created successfully");
                    console.log(res.data);
                }
                else {
                    alert("Error created customer");
                }
            })

    }
    

    render() {

        return (
            <div>
            <div style={{height:'50px',width:'50px'}}>
            <table >
            <tbody>
        <tr>
            <th><img src="https://av.sc.com/corp-en/content/images/SC_Full_colour_preview_logo.jpg" /></th>
        </tr>
        </tbody>
        </table>
        </div>

            
            <div style={{ backgroundRepeat: 'no-repeat', height: 1000, backgroundSize: 'cover', marginTop: -17, backgroundPosition: 'center' }}>

                <div className="row" >

                    <div className="col-sm-8 col-sm-offset-2">
                        <h1 style={{ alignContent: 'center', textAlign: 'center', color: 'black', marginTop: '10px', marginLeft: '50px' }}>STANDARD CHARTERED BANK</h1>
                        <div className="panel panel-default">
                            <div className="panel-heading">
                                <h5 className="text-center" style={{ fontWeight: '600', color: 'black', marginLeft: '50px' }} > Offline Form Upload Portal</h5>
                            </div>
                            <div className="panel-body">

                                <form className="form-horizontal"  >
                                    <div className="form-group">
                                        <label className="control-label col-sm-4" style={{ color: 'black' }} >Name:</label>
                                        <div className="col-sm-4">
                                            <input type="text" className="form-control" id="name" placeholder="Enter name" name="name"
                                                required />
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <label className="control-label col-sm-4" style={{ color: 'black' }} >Company:</label>
                                        <div className="col-sm-4">
                                            <input type="text" className="form-control" id="company" placeholder="Company Name" name="company"
                                                required />
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-4" style={{ color: 'black' }} >Country:</label>
                                        <div className="col-sm-4">
                                            <input type="text" className="form-control" id="country" placeholder="Country" name="country"
                                                required />
                                        </div>
                                    </div>

                                    

                                    <div className="form-group">
                                        <label className="control-label col-sm-4" style={{ color: 'black' }} >Address:</label>
                                        <div className="col-sm-4">
                                            <input type="text" className="form-control" id="address" placeholder="Address" name="address"
                                                required />
                                        </div>
                                    </div>
                                    
                                    

                                    

                                    <div className="form-group">
                                        <label className="control-label col-sm-4" style={{ color: 'black' }} >Aadhaar Card:</label>
                                       
                                        <div className="col-sm-4" style={{ color: 'black' }}>
                                            <input type="file" id="ac" placeholder="Attachment" name="ac"
                                                required />
                                        </div>

                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-4" style={{ color: 'black' }} >PAN Card:</label>
                                       
                                        <div className="col-sm-4" style={{ color: 'black' }}>
                                            <input type="file" id="address1" name="address"
                                                required />
                                        </div>



                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-4" style={{ color: 'black' }} >Offline Form:</label>

                                        <div className="col-sm-4" style={{ color: 'black' }}>
                                            <input type="file" id="address2" name="address"
                                                required />
                                        </div>



                                    </div>








                                    <div className="but-al">

                                        <div className="form-group">
                                            <div className=" col-sm-8 col-sm-offset-6" style={{ color: 'black' }}>
                                                <button className="btn btn-success" onClick={this.handleEvent}>Submit</button>

                                                <button type="reset" className="btn btn-default" style={{ color: 'black' }}>Reset</button>
                                            </div>


                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
           </div>
           </div>

                );
            }
        
        }
        
        
export default FinalForm