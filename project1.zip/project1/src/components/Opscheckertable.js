import React from "react";
import axios from "axios";
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdbreact';
import { Link } from 'react-router-dom';

class Opscheckertable extends React.Component {
    state = {
    };

    componentDidMount() {
        axios.get('http://localhost:9090/task/showData2')
            .then(res => {
                console.log(res);
                this.setState(
                    {
                        customers: res.data
                    }
                )
            }).catch(err => {
                console.log(err);
            })
    }

    getTableRows = () => {
        const { customers } = this.state;
        if (!customers)
            return null;

        const allRows = customers.map((c, i) => (
            <tr key={i}>
                <td>{c.transaction_ref_no}</td>
                <td>{c.curr_step_name}</td>
                <td>{c.last_step_name}</td>
                <td>{c.processDate}</td>
                <td>{c.status}</td>
                <td><Link to={'/customerschecker/' + c.transaction_ref_no} >Edit </Link>&nbsp;&nbsp;
            </td>
            </tr>
        ));
        return allRows;
    }


    getCustTable = () => {
        return (
            <MDBTable className="table table-bordered table-striped">
                <MDBTableHead color="primary-color" >
                    <tr>
                        <th>TRANSACTION REFERENCE NUMBER</th>
                        <th>CURRENT STEP NAME</th>
                        <th>LAST STEP NAME</th>
                        <th>PROCESS DATE</th>
                        <th>STATUS</th>
                        <th>LINK</th>
                    </tr>
                </MDBTableHead>
                <MDBTableBody>
                    {
                        this.getTableRows()
                    }
                </MDBTableBody>
            </MDBTable>
        )
    }


    render() {
        return (
            <div>
                <p>Testing</p>
                {
                    this.getCustTable()
                }
            </div>
        )
    }
}

export default Opscheckertable;