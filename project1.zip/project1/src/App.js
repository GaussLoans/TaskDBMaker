import React from 'react';
// import {BrowserRouter,Switch,Route,Link} from 'react-router-dom'
//import logo from './logo.svg';
//import FinalForm from './subscribeForm';
//import LoginPage from './components/loginpage';
import './App.css';
//import FinalForm from './components/FinalForm';
//import LoginPage from './components/loginpage';
//import FormPage from './components/loans';
import Options from './components/Options'
import Login from './components/Login';
import FinalForm from './components/FinalForm';
import Opsmakertable from './components/Opsmakertable';
import {BrowserRouter,Switch,Route} from 'react-router-dom';
import LoginPage from './components/LoginPage';
import LoginPage1 from './components/LoginPage1';
import Opscheckertable from './components/Opscheckertable';

class App extends React.Component {
  render(){
  return (
    <div>      
    <BrowserRouter>
    <Switch>
      <Route exact path = "/" component={Login}/>
      <Route path="/options" component={Options}/>
      <Route path="/frontdesk" component={FinalForm}/>
      <Route path="/opsmaker" component={Opsmakertable}/>
      <Route path="/opschecker" component={Opscheckertable}/>
      <Route path="/customers/"  component={LoginPage}/>
      <Route path="/customerschecker" component={LoginPage1}/>
    </Switch>
    </BrowserRouter>
    </div>
  );
}
}

export default App;
