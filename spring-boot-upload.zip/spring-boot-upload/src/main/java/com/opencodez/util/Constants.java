package com.opencodez.util;

public class Constants {
	
	//public static final String UPLOAD_LOCATION = "C:\\documents\\loanfile\\upload-dir\\";
	
	public static final String UPLOAD_LOCATION = "C:\\Users\\1607184\\Downloads\\spring-boot-upload\\src\\main\\resources\\static\\loanfiles";

}
