package com.scb.gauss.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.scb.gauss.bean.CustomerInformation;

@Repository
public class CustomerInformationDAOImpl extends JdbcDaoSupport implements CustomerInformationDAO{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	 @Autowired
	 private DataSource dataSource;
	
	@PostConstruct
	 private void initialize() {
	  setDataSource(dataSource);
	 }
	
	//Adding
	public int add(CustomerInformation customer) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO \"customer_information\"(country,customer_name,address,company,salary,loan_amount,loan_type,aadhar,pancard,email) VALUES(?,?,?,?,?,?,?,?,?,?)";
		return jdbcTemplate.update(query, new Object[]{
				customer.getCountry(),customer.getCustomer_name(),customer.getAddress(),customer.getCompany(),customer.getSalary(),customer.getLoan_amount(),customer.getLoan_type(),customer.getAadhar(),customer.getPancard(),customer.getEmail()
		});
	}
	

	//Display all the records
	@Override
	public List<CustomerInformation> list() {
		String query = "SELECT * FROM \"customer_information\"";
		return jdbcTemplate.query(query, new CustomerInformationMapper());
	}
	class CustomerInformationMapper implements RowMapper<CustomerInformation> {

		@Override
		public CustomerInformation mapRow(ResultSet rs, int rowNum) throws SQLException {
			CustomerInformation customer = new CustomerInformation();
			customer.setCountry(rs.getString("country"));
			customer.setCustomer_name(rs.getString("customer_name"));
			customer.setAddress(rs.getString("address"));
			customer.setCompany(rs.getString("company"));
			customer.setSalary(rs.getLong("salary"));
			customer.setLoan_amount(rs.getLong("loan_amount"));
			customer.setAadhar(rs.getLong("aadhar"));
			customer.setPancard(rs.getString("pancard"));
			customer.setEmail(rs.getString("email"));
			
	
			return customer;
		}
		
	}
	

}
