package com.scb.gauss.dao;

import java.util.List;

import com.scb.gauss.bean.CustomerInformation;

public interface CustomerInformationDAO {
	public int add(CustomerInformation customer);
	public List<CustomerInformation> list();

}
