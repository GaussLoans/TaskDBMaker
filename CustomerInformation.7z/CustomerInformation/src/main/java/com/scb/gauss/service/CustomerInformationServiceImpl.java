package com.scb.gauss.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.gauss.bean.CustomerInformation;
import com.scb.gauss.dao.CustomerInformationDAO;

@Service

public class CustomerInformationServiceImpl implements CustomerInformationService {

	@Autowired
	private CustomerInformationDAO CustomerDAO;

	@Override
	public int add(CustomerInformation customer) {
		return CustomerDAO.add(customer);
	}
	
	@Override
	public List<CustomerInformation> list() {
		return CustomerDAO.list();
	}

	
}
