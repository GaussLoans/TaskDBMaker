import React from 'react';
//import logo from './logo.svg';
import './App.css';
import FinalForm from './frontdesk/FinalForm';
//import Login from './login/Login';
//import ud from './containers/bg3.jpg';
//import FormCreation from './login/FormCreation'
//import FileUpload from './fileupload/FileUpload';



function App() {
  return (
    <div >
      {/* <Login/> */}
    {/* <FormCreation/>  */}
    {/* <FileUpload/>  */}
    
     <FinalForm/>

    </div>


  );
}

export default App;
