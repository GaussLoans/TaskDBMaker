
import React from 'react'
import axios from 'axios'
import { thisExpression } from '@babel/types';
//import bg3 from './bg3.jpg'
//import Header from './header'
class FinalForm extends React.Component {
    state={
    task:{
        curr_step_name:'',
        last_step_name:'',
        status:'',
        process_date:''

    },
    formData : {
        adhaar: null
    },
    done:false
}

// Register when the file changes in the inut box
    handleFileChange = (e) => {
        if (e.target.name === "adhaar" || e.target.name === 'offlineform' || e.target.name === "pan") {
            this.setState({
                formData: {
                    ...this.state.formData,
                    [e.target.name]: e.target.files[0]
                }
            });
        }
        else {
            this.setState({
                formData: {
                    ...this.state.formData,
                    [e.target.name]: e.target.value
                }
            });
        }
        console.log(this.state.formData)
    }

submitFormHandler=()=>{
    let formData = new FormData();
    formData.append('adhaar',this.state.formData.adhaar);
    formData.append('pan',this.state.formData.pan);
    formData.append('offlineform',this.state.formData.offlineform)
    axios.post('http://localhost:4893/files/upload' ,formData,{
        headers: {
            'content-type' : 'multipart/form-data'
        }
    }).then((res)=>{
        alert("Upload Success"+res)
    }).catch((e)=>{
        alert("Upload Failed"+e)
    })
}

handleEvent = (e) => {
    e.preventDefault();
    var d=new Date();
    let date=d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();
    console.log(date);
    axios.post(`http://localhost:9090/task/addData`, {
      curr_step_name:"opsmaker",
      last_step_name:"frontdesk",
     // process_date:date,
      status:"pending"
    })
        .then(res => {
            if (res.data > 0) {
                alert("Customer created successfully");
                console.log(res.data);
            }
            else {
                alert("Error created customer");
            }
        })
         
}


render() {

    return (
        <div>
        <div style={{height:'50px',width:'50px'}}>
        <table >
        <tbody>
    <tr>
        <th><img src="https://av.sc.com/corp-en/content/images/SC_Full_colour_preview_logo.jpg" /></th>
    </tr>
    </tbody>
    </table>
    </div>

        
        <div style={{ backgroundRepeat: 'no-repeat', height: 1000, backgroundSize: 'cover', marginTop: -17, backgroundPosition: 'center' }}>

            <div className="row" >

                <div className="col-sm-8 col-sm-offset-2">
                    <h1 style={{ alignContent: 'center', textAlign: 'center', color: 'black', marginTop: '10px', marginLeft: '50px' }}>STANDARD CHARTERED BANK</h1>
                    <div className="panel panel-default">
                        <div className="panel-heading">
                            <h5 className="text-center" style={{ fontWeight: '600', color: 'black', marginLeft: '50px' }} > Offline Form Upload Portal</h5>
                        </div>
                        <div className="panel-body">

                            <form className="form-horizontal"  >
                                <div className="form-group">
                                    <label className="control-label col-sm-4" style={{ color: 'black' }} >Name:</label>
                                    <div className="col-sm-4">
                                        <input type="text" className="form-control" id="name" placeholder="Enter name" name="name"  onChange={this.handleFileChange}
                                            required />
                                    </div>
                                </div>

                                <div className="form-group">
                                    <label className="control-label col-sm-4" style={{ color: 'black' }} >Company:</label>
                                    <div className="col-sm-4">
                                        <input type="text" className="form-control" id="company" placeholder="Company Name" name="company"  onChange={this.handleFileChange}
                                            required />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <label className="control-label col-sm-4" style={{ color: 'black' }} >Country:</label>
                                    <div className="col-sm-4">
                                        <input type="text" className="form-control" id="country" placeholder="Country" name="country"  onChange={this.handleFileChange}
                                            required />
                                    </div>
                                </div>

                                

                                <div className="form-group">
                                    <label className="control-label col-sm-4" style={{ color: 'black' }} >Address:</label>
                                    <div className="col-sm-4">
                                        <input type="text" className="form-control" id="address" placeholder="Address" name="address"  onChange={this.handleFileChange}
                                            required />
                                    </div>
                                </div>
                                
                                

                                

                                <div className="form-group">
                                    <label className="control-label col-sm-4" style={{ color: 'black' }} >Aadhaar Card:</label>
                                   
                                    <div className="col-sm-4" style={{ color: 'black' }}>
                                        <input type="file" id="ac" placeholder="Attachment" name="adhaar" onChange={this.handleFileChange}
                                            required />
                                    </div>

                                </div>
                                <div className="form-group">
                                    <label className="control-label col-sm-4" style={{ color: 'black' }} >PAN Card:</label>
                                   
                                    <div className="col-sm-4" style={{ color: 'black' }}>
                                        <input type="file" id="address1" name="pan" onChange={this.handleFileChange}
                                            required />
                                    </div>



                                </div>
                                <div className="form-group">
                                    <label className="control-label col-sm-4" style={{ color: 'black' }} >Offline Form:</label>

                                    <div className="col-sm-4" style={{ color: 'black' }}>
                                        <input type="file" id="address2" name="offlineform" onChange={this.handleFileChange}
                                            required />
                                    </div>



                                </div>








                                <div className="but-al">

                                    <div className="form-group">
                                        <div className=" col-sm-8 col-sm-offset-6" style={{ color: 'black' }}>
                                            <button className="btn btn-success" onClick={this.submitFormHandler}>Submit</button>

                                            <button type="reset" className="btn btn-default" style={{ color: 'black' }}>Reset</button>
                                        </div>


                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
       </div>
       </div>

            );
        }
    
    }
    
    
export default FinalForm