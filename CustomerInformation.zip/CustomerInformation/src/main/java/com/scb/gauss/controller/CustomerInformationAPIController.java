package com.scb.gauss.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.gauss.bean.CustomerInformation;
import com.scb.gauss.service.CustomerInformationService;

@RestController
@RequestMapping("/customerinformation")
public class CustomerInformationAPIController {

	@Autowired
	private CustomerInformationService customerinformationService;

	/* Adding a resource */
	@PostMapping("/add")
	private int add(@RequestBody CustomerInformation customer) {
		return customerinformationService.add(customer);
	}
	
	/* Getting a list of resources */
	@GetMapping("/")
	private Collection<CustomerInformation> list() {
		return customerinformationService.list();
	}


}
