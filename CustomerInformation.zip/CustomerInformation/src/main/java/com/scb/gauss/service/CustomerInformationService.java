package com.scb.gauss.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.scb.gauss.bean.CustomerInformation;
@Service
public interface CustomerInformationService {

	public int add(CustomerInformation customer);
	public List<CustomerInformation> list();

}
