import React from 'react';
//import logo from './logo.svg';
import './App.css';
import Login from "./containers/Login";
//import ud from './containers/bg3.jpg';
import FormCreation from './containers/formCreationMessage'

function App() {
  return (
    <div >
    <Login/>
    <FormCreation/>
    </div>
  );
}

export default App;
